namespace MvvmCross.Platforms.Android.Binding
{
    internal static class MvxPreferencePropertyBinding
    {
        public const string Preference_Value = "Value";
        public const string EditTextPreference_Text = "Text";
        public const string ListPreference_Value = "Value";
        public const string TwoStatePreference_Checked = "Checked";
        public const string Preference_Click = "PreferenceClick";
    }
}
