---

name: 💬 Questions and Help
about: If you have questions, please use this for support
---

## 💬 Questions and Help

Please do not use GitHub Issues for questions. Instead questions or help we recommend using:

- [Q&A category in our Discussions](https://github.com/MvvmCross/MvvmCross/discussions)
- The [MvvmCross tag in Stack Overflow](https://stackoverflow.com/questions/tagged/mvvmcross)
- The [MvvmCross channel in the DotNetEvolution Discord](https://aka.ms/dotnet-discord)
